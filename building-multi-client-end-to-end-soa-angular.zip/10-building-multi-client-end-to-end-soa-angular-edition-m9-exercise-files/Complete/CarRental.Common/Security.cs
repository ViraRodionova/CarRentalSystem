﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRental.Common
{
    public static class Security
    {
        public const string CarRentalUser = "CarRentalUser";

        public const string CarRentalAdminRole = "CarRentalAdmin";
    }
}
