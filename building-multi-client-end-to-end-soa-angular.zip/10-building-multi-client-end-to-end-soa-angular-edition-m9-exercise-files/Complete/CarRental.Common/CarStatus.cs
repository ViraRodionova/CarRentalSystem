﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CarRental.Common
{
    public enum CarStatus
    {
        Online,
        Offline
    };
}
