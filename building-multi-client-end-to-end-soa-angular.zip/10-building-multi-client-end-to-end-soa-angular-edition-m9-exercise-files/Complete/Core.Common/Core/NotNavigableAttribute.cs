using System;
using System.Collections.Generic;
using System.Linq;

namespace Core.Common.Core
{
    [AttributeUsage(AttributeTargets.Property)]
    public class NotNavigableAttribute : Attribute
    {
    }
}
