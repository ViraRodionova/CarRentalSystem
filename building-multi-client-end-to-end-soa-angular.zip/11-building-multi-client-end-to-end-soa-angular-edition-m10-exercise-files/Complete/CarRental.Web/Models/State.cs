﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarRental.Web.Models
{
    public class State
    {
        public string Abbrev { get; set; }
        public string Name { get; set; }
    }
}